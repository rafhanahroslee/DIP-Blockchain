const options = [
  {id:"candidate1", text:"Name1", votes:0},
  {id:"candidate2", text:"Name2", votes:0},
  {id:"candidate3", text:"Name3", votes:0},
];

function submitVote(){
  const selectedCandidate = document.querySelector('input[name="poll"]:checked');

  if(!selectedCandidate){
    alert("Please select a candidate.");
    return;
  }

  const candicateId = selectedCandidate.ariaValueMax;
  const selectedCandidateObj = options.find((option)=> option.id === optionId);

  if(selectedCandidateObj){
    selectedCandidateObj.votes++;
    console.log(selectedCandidateObj);
    displayResult();
  }
}

function displayResult(){
  const result = document.getElementById('result');
  result.innerHTML = "";

  options.forEach((option)=>{
    const percentage = ((option.votes/ etTotalVotes()) * 100).toFixed(2) || 0;
    const barWidth = percentage > 0? percentage + "%" : "0%";

    const candidateResult = document.createElement("div");
    candidateResult.className = "candidateResult";
    candidateResult.innerHTML = `
      <span class = "candidateText">${option.text}</span>
      <div class = "barContainer">
        <div class = "bar" style="width": ${barWidth};"></div>
      </div>
      <span class = "percentage">${percentage}%</span>
      `;

      result.appendChild(candidateResult);
  });
}

function getTotalVotes(){
  return options.reduce((total,option)=> total + option.votes,0);
}

displayResult();