const connect = document.querySelector('.wallet-button');
const voteButtons = document.querySelectorAll(".vote-button");

connect.addEventListener('click', event => {
  let account;
  ethereum.request({ method: 'eth_requestAccounts' }).then(accounts => {
    account = accounts[0];
    console.log(account);
    // Format address (e.g., 0x1234...abcd)
    const shortAddress = account.slice(0, 6) + "..." + account.slice(-5);
    document.getElementById("walletAddress").textContent = `${shortAddress}`;
    connect.textContent = "Connected";

    // add codes here if acc connected then
    showAlreadyVotedPopup();
    disableVoteButtons(); // Disable the vote buttons
  });
});

function showAlreadyVotedPopup() {
  const alreadyVotedPopup = document.getElementById("alreadyVotedPopup");
  const closeBtn = document.getElementById("closeAlreadyVotedPopup");

  alreadyVotedPopup.style.display = "block"; // Corrected style to "block"

  closeBtn.onclick = function () {
    alreadyVotedPopup.style.display = "none"; // Hide the popup on close
  };
}

voteButtons.forEach(button => {
  button.addEventListener("click", function (event) {
    const selectedCandidate = event.target.closest('.profiles').querySelector('strong').textContent;

    // Show confirmation popup
    const popup = document.getElementById("votePopup");
    const confirmBtn = document.getElementById("confirmVote");
    const cancelBtn = document.getElementById("cancelVote");

    // Position the popup near the clicked button
    const rect = button.getBoundingClientRect(); // Get the button's position
    popup.style.top = `${rect.top + window.scrollY + 40}px`; 
    popup.style.left = `${rect.left + window.scrollX}px`; 
    popup.style.display = "block";

    confirmBtn.onclick = function () {
      // Mark the user as having voted by storing the wallet address
      const account = document.getElementById("walletAddress").textContent;
      localStorage.setItem(account, "voted");
      alert(`Your vote for ${selectedCandidate} has been submitted successfully!`);
      popup.style.display = "none"; // Close the popup
      disableVoteButtons(); // Disable the vote buttons
    };

    cancelBtn.onclick = function () {
      popup.style.display = "none"; // Close the popup if canceled
    };
  });
});

// Disable voting buttons after the user has voted
function disableVoteButtons() {
  voteButtons.forEach(button => {
    button.disabled = true;
  });
}

// Close the popup if the user clicks outside of it
document.addEventListener("click", function (event) {
  const popup = document.getElementById("votePopup");
  if (!popup.contains(event.target) && !event.target.classList.contains("vote-button")) {
    popup.style.display = "none";
  }
});

document.getElementById("logout-button").addEventListener("click", function() {
  // Clear any stored session data (e.g., localStorage or sessionStorage)
   localStorage.clear();
   sessionStorage.clear();

   // Redirect to the login page
   window.location.href = "../Login (1)/Login (1).html";
});