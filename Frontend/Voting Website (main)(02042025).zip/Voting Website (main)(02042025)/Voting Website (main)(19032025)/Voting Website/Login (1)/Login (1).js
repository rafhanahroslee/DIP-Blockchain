const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const loginButton = document.querySelector('.button');

// Toggle between login and register forms
registerLink.addEventListener('click', () => {
    wrapper.classList.add('active');
});

loginLink.addEventListener('click', () => {
    wrapper.classList.remove('active');
});

document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.querySelector(".form-box.login form");
    const emailInput = loginForm.querySelector("input[type='email']");
    const passwordInput = loginForm.querySelector("input[type='password']");

    // Admin credentials
    const adminEmail = "admin@e.ntu.edu.sg";  // Replace with your admin email
    const adminPassword = "123";  // Replace with your admin password

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent default form submission

        // Remove any existing error messages
        document.querySelectorAll(".error-message").forEach(el => el.remove());

        const emailValue = emailInput.value.trim();
        const passwordValue = passwordInput.value.trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 

        let valid = true; // Track validation status

        // Check for empty fields
        if (emailValue === "") {
            showError(emailInput, "Please fill out this field.");
            valid = false;
        } else if (!emailPattern.test(emailValue)) {
            showError(emailInput, "Please enter a valid email address.");
            valid = false;
        }

        if (passwordValue === "") {
            showError(passwordInput, "Please fill out this field.");
            valid = false;
        }

        // Check for admin credentials if valid
        if (valid) {
            if (emailValue === adminEmail && passwordValue === adminPassword) {
                alert("Admin logged in successfully!");
                window.location.href = "../Admin page/admin.html";  // Corrected path
            } else {
                window.location.href = "../Voting (2)/Voting (2).html"; // Redirect to voting page if regular user
            }
        }
    });

    // Function to show tooltip-like error messages
    function showError(inputField, message) {
        const errorDiv = document.createElement("div");
        errorDiv.classList.add("error-message");
        errorDiv.innerText = message;
        errorDiv.style.color = "red";
        errorDiv.style.fontSize = "0.9em";
        errorDiv.style.position = "absolute";
        errorDiv.style.marginTop = "2px";

        inputField.parentElement.appendChild(errorDiv);
    }
});
