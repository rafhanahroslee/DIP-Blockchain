const connect = document.querySelector('.wallet-button');


connect.addEventListener('click', event => {
  let account;
  ethereum.request({method: 'eth_requestAccounts'}).then(accounts => {
    account = accounts[0];
    console.log(account);
     // Format address (e.g., 0x1234...abcd)
     const shortAddress = account.slice(0, 6) + "..." + account.slice(-5);
     document.getElementById("walletAddress").textContent=`${shortAddress}`;
     connect.textContent = "Connected";

  });

});