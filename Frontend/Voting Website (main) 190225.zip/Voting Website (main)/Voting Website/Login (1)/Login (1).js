const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const loginButton = document.querySelector('.button');


registerLink.addEventListener('click', ()=> {
  wrapper.classList.add('active');
});

loginLink.addEventListener('click', ()=> {
  wrapper.classList.remove('active');
});

// Redirect to voting page on login
loginButton.addEventListener('click', (event) => {
  event.preventDefault(); // Prevent default form submission
  window.location.href = "../Voting (2)/Voting (2).html"; // Redirect to the voting page
});

  