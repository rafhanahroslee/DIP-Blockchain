const connect = document.querySelector('.wallet-button');
const voteButtons = document.querySelectorAll(".vote-button");

let account;
let contract;

// --- SETUP ETHERS.JS ---
const provider = new ethers.providers.Web3Provider(window.ethereum);
const signer = provider.getSigner();
const contractAddress = "YOUR_CONTRACT_ADDRESS_HERE"; // 🔁 Replace with your deployed contract address
const contractABI = [ /* YOUR_CONTRACT_ABI_HERE */ ]; // 🔁 Replace with your smart contract ABI

contract = new ethers.Contract(contractAddress, contractABI, signer);

// Connect Wallet
connect.addEventListener('click', async () => {
  try {
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    account = accounts[0];
    console.log("Connected account:", account);

    const shortAddress = account.slice(0, 6) + "..." + account.slice(-5);
    document.getElementById("walletAddress").textContent = `${shortAddress}`;
    connect.textContent = "Connected";

    // 🔍 Check if user already voted
    const hasVoted = await contract.hasVoted(account);
    if (hasVoted) {
      showAlreadyVotedPopup();
      disableVoteButtons(); 
    }
  } catch (error) {
    console.error("Wallet connection failed:", error);
  }
});

// Show Already Voted Popup
function showAlreadyVotedPopup() {
  const alreadyVotedPopup = document.getElementById("alreadyVotedPopup");
  const closeBtn = document.getElementById("closeAlreadyVotedPopup");

  alreadyVotedPopup.style.display = "block";
  closeBtn.onclick = () => {
    alreadyVotedPopup.style.display = "none";
  };
}


voteButtons.forEach(button => {
  button.addEventListener("click", function (event) {
    const selectedCandidate = event.target.closest('.profiles').querySelector('strong').textContent;

    const popup = document.getElementById("votePopup");
    const confirmBtn = document.getElementById("confirmVote");
    const cancelBtn = document.getElementById("cancelVote");

    const rect = button.getBoundingClientRect();
    popup.style.top = `${rect.top + window.scrollY + 40}px`; 
    popup.style.left = `${rect.left + window.scrollX}px`; 
    popup.style.display = "block";

    // confirms votes
    confirmBtn.onclick = async function () {
      try {
        const tx = await contract.castVote(selectedCandidate); // smart contract function
        await tx.wait(); 

        alert(`Your vote for ${selectedCandidate} has been recorded on the blockchain!`);
        popup.style.display = "none";
        disableVoteButtons();
      } catch (error) {
        console.error("Voting failed:", error);
        alert("There was an error submitting your vote. Please try again.");
      }
    };

    cancelBtn.onclick = function () {
      popup.style.display = "none";
    };
  });
});

// Disable all voting buttons
function disableVoteButtons() {
  voteButtons.forEach(button => {
    button.disabled = true;
  });
}

// Close popup when clicking outside
document.addEventListener("click", function (event) {
  const popup = document.getElementById("votePopup");
  if (!popup.contains(event.target) && !event.target.classList.contains("vote-button")) {
    popup.style.display = "none";
  }
});

// Logout
document.getElementById("logout-button").addEventListener("click", function() {
  localStorage.clear();
  sessionStorage.clear();
  window.location.href = "../Login (1)/Login (1).html";
});
