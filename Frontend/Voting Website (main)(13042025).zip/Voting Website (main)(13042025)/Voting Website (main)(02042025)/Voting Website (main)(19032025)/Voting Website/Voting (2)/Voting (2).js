// Part 1: Wallet Connection and Initialization
const connect = document.querySelector('.wallet-button');
window.userWalletAddress = null;
let contractAddress;

connect.addEventListener('click', event => {
    ethereum.request({ method: 'eth_requestAccounts' }).then(accounts => {
        window.userWalletAddress = accounts[0];
        contractAddress = "0x21efdb28e0a54975d1fc0ad20f2735f5c324ac03"; 
        console.log(window.userWalletAddress);

        const shortAddress = window.userWalletAddress.slice(0, 6) + "..." + window.userWalletAddress.slice(-5);
        document.getElementById("walletAddress").textContent = `${shortAddress}`;
        connect.textContent = "Connected";
    });
});
// Part 2: Vote Button Logic
document.addEventListener("DOMContentLoaded", function () {
    const voteButtons = document.querySelectorAll(".vote-button");
    const popup = document.getElementById("votePopup");
    const confirmBtn = document.getElementById("confirmVote");
    const cancelBtn = document.getElementById("cancelVote");

    let hasVoted = false; // Flag to track voting status

    voteButtons.forEach((button, index) => {
        button.addEventListener("click", function (event) {
            if (hasVoted) {
                alert("You have already voted.");
                return;
            }

            const rect = button.getBoundingClientRect();
            popup.style.top = `${rect.top + window.scrollY + 40}px`;
            popup.style.left = `${rect.left + window.scrollX}px`;
            popup.style.display = "block";

            confirmBtn.onclick = async function () {
                if (!window.userWalletAddress) {
                    alert("Please connect your wallet first.");
                    return;
                }
                try {
                    const candidateId = index + 1;
                    const candidateIdNumber = parseInt(candidateId);
                    if (isNaN(candidateIdNumber)) {
                        throw new Error("Invalid candidate ID");
                    }
                    // Assuming 'electionABI' and contractAddress are defined elsewhere in your code
                    const contract = new web3.eth.Contract(electionABI, contractAddress);
                    const encodedFunctionCall = contract.methods.vote(candidateIdNumber).encodeABI();
                    console.log("Candidate ID:", candidateIdNumber);
                    console.log("Encoded Function Call:", encodedFunctionCall);
                    const transactionParameters = {
                        to: contractAddress,
                        from: window.userWalletAddress,
                        data: encodedFunctionCall,
                    };
                    const txHash = await ethereum.request({
                        method: "eth_sendTransaction",
                        params: [transactionParameters],
                    });
                    console.log("Transaction Hash:", txHash);
                    alert(`Voted`);
                    popup.style.display = "none";
                    document.getElementById("votingStatus").textContent = "Voted";
                    // Disable vote buttons and set hasVoted flag
                    voteButtons.forEach((btn) => {
                        btn.disabled = true;
                    });
                    hasVoted = true;
                    // Store voting status in localStorage
                    localStorage.setItem('voted_' + window.userWalletAddress, 'true');
                    console.log("Voting status stored:", localStorage.getItem('voted_' + window.userWalletAddress)); // Add this line
                } catch (error) {
                    console.error("Error sending transaction:", error);
                    alert(`Transaction failed: ${error.message}`);
                }
            };
            cancelBtn.onclick = function () {
                popup.style.display = "none";
            };
        });
    });

    document.addEventListener("click", function (event) {
        if (!popup.contains(event.target) && !event.target.classList.contains("vote-button")) {
            popup.style.display = "none";
        }
    });
    document.getElementById("logout-button").addEventListener("click", function () {
        window.location.href = "index.html";
    });
    async function checkCandidatesCount() {
        try {
            if (!window.userWalletAddress) {
                alert("Please connect your wallet first.");
                return;
            }
            // Assuming 'electionABI' and contractAddress are defined elsewhere in your code
            const contract = new web3.eth.Contract(electionABI, contractAddress);
            const count = await contract.methods.candidatesCount().call({ from: window.userWalletAddress });
            console.log("Candidates Count:", count);
            if (count == 0) {
                alert("No candidates have been registered. Please register candidates.");
            }
        } catch (error) {
            console.error("Error checking candidates count:", error);
        }
    }

    window.addEventListener("load", async () => {
        if (window.ethereum) {
            window.web3 = new Web3(ethereum);
            try {
                // Request accounts *first*
                const accounts = await ethereum.request({ method: "eth_requestAccounts" });
                window.userWalletAddress = accounts[0];
                console.log("metamask connected");

                // Retrieve and display matric and email
                const matric = localStorage.getItem('matric');
                const email = localStorage.getItem('email');
                if (matric && email) {
                    document.getElementById('displayMatric').textContent = matric;
                    document.getElementById('displayEmail').textContent = email;
                }

                // *Now* check voting status from localStorage
                if (localStorage.getItem('voted_' + window.userWalletAddress) === 'true') {
                    document.getElementById("votingStatus").textContent = "Voted";
                    const voteButtons = document.querySelectorAll(".vote-button"); //select all vote buttons
                    voteButtons.forEach((btn) => {
                        btn.disabled = true;
                    });
                    hasVoted = true;
                }
                await checkCandidatesCount();
            } catch (error) {
                console.error(error);
            }
        } else if (window.web3) {
            window.web3 = new Web3(web3.currentProvider);
        } else {
            console.log(
                "Non-Ethereum browser detected. \
         You should consider trying MetaMask!"
            );
        }
    });
});

// Part 3: ABI 
const electionABI = [
    {
        "inputs": [], // Corrected
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "_CfirstName",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_ClastName",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_CidNumber",
                "type": "string"
            }
        ],
        "name": "addCandidate",
        "outputs": [], // Corrected
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "_firstName",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_lastName",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_idNumber",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_email",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_password",
                "type": "string"
            }
        ],
        "name": "addUser",
        "outputs": [], // Corrected
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [], // Corrected
        "name": "candidatesCount",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [], // Corrected
        "name": "manager",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "_candidateId",
                "type": "uint256"
            }
        ],
        "name": "vote",
        "outputs": [], // Corrected
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "name": "voters",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "candidates",
        "outputs": [
            {
                "components": [
                    {
                        "internalType": "uint256",
                        "name": "id",
                        "type": "uint256"
                    },
                    {
                        "internalType": "string",
                        "name": "CfirstName",
                        "type": "string"
                    },
                    {
                        "internalType": "string",
                        "name": "ClastName",
                        "type": "string"
                    },
                    {
                        "internalType": "string",
                        "name": "CidNumber",
                        "type": "string"
                    },
                    {
                        "internalType": "uint256",
                        "name": "voteCount",
                        "type": "uint256"
                    }
                ],
                "internalType": "struct Election.Candidate",
                "name": "",
                "type": "tuple"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "users",
        "outputs": [
            {
                "components": [
                    {
                        "internalType": "string",
                        "name": "firstName",
                        "type": "string"
                    },
                    {
                        "internalType": "string",
                        "name": "lastName",
                        "type": "string"
                    },
                    {
                        "internalType": "string",
                        "name": "idNumber",
                        "type": "string"
                    },
                    {
                        "internalType": "string",
                        "name": "email",
                        "type": "string"
                    },
                    {
                        "internalType": "string",
                        "name": "password",
                        "type": "string"
                    },
                    {
                        "internalType": "address",
                        "name": "add",
                        "type": "address"
                    }
                ],
                "internalType": "struct Election.User",
                "name": "",
                "type": "tuple"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [], // Corrected
        "name": "usersCount",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "uint256",
                "name": "_candidateId",
                "type": "uint256"
            }
        ],
        "name": "votedEvent",
        "type": "event"
    }
];