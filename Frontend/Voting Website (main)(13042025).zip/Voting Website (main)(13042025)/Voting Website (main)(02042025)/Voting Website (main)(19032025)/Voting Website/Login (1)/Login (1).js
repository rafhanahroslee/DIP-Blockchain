const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');

// Toggle between login and register forms
registerLink.addEventListener('click', () => {
    wrapper.classList.add('active');
});
loginLink.addEventListener('click', () => {
    wrapper.classList.remove('active');
});

function initLoginForm() {
    const loginForm = document.querySelector(".form-box.login form");
    const registerForm = document.querySelector(".form-box.register form");
    const loginEmailInput = loginForm.querySelector("input[type='email']");
    const loginPasswordInput = loginForm.querySelector("input[type='password']");
    const regMatricInput = registerForm.querySelector("input[type='text']");
    const regEmailInput = registerForm.querySelector("input[type='email']");
    const regPasswordInput = registerForm.querySelector("input[type='password']");
    const termsCheckbox = registerForm.querySelector("input[type='checkbox']");

    const allowedMatricNumbers = [
        "U2321085K", "U2322941H", "U2323055L", "U2321550B",
        "U2323583H", "U2323531C", "U2322210L", "U2322627L", "U2222995K"
    ];

    // Registration
    registerForm.addEventListener("submit", function (event) {
        event.preventDefault();
        document.querySelectorAll(".error-message").forEach(el => el.remove());
        let valid = true;

        if (regMatricInput.value.trim() === "") {
            showError(regMatricInput, "Please enter your Matric Number.");
            valid = false;
        } else if (!allowedMatricNumbers.includes(regMatricInput.value.trim())) {
            showError(regMatricInput, "Invalid Matric Number.");
            valid = false;
        }

        if (regEmailInput.value.trim() === "") {
            showError(regEmailInput, "Please enter your email.");
            valid = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(regEmailInput.value.trim())) {
            showError(regEmailInput, "Please enter a valid email address.");
            valid = false;
        } else if (!regEmailInput.value.endsWith("@e.ntu.edu.sg")) {
            showError(regEmailInput, "Email must end with @e.ntu.edu.sg");
            valid = false;
        }

        if (regPasswordInput.value.trim() === "") {
            showError(regPasswordInput, "Please enter a password.");
            valid = false;
        }

        if (!termsCheckbox.checked) {
            alert("Please agree to the terms & conditions before registering.");
            valid = false;
        }

        if (valid) {
            const userData = {
                matric: regMatricInput.value.trim(),
                password: regPasswordInput.value.trim()
            };
            localStorage.setItem(regEmailInput.value.trim(), JSON.stringify(userData));
            localStorage.setItem('matric', regMatricInput.value.trim());
            localStorage.setItem('email', regEmailInput.value.trim());
            alert("Registration successful!");
            wrapper.classList.remove('active');
        }
    });

    // Login
    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        document.querySelectorAll(".error-message").forEach(el => el.remove());

        const emailValue = loginEmailInput.value.trim();
        const passwordValue = loginPasswordInput.value.trim();
        const rememberMe = document.querySelector('.remember-forgot input[type="checkbox"]');

        let valid = true;

        if (emailValue === "") {
            showError(loginEmailInput, "Please enter your email.");
            valid = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
            showError(loginEmailInput, "Please enter a valid email address.");
            valid = false;
        }

        if (passwordValue === "") {
            showError(loginPasswordInput, "Please enter your password.");
            valid = false;
        }

        if (valid) {
            if (emailValue === "admin@e.ntu.edu.sg" && passwordValue === "123") {
                alert("Admin logged in successfully!");
                window.location.href = "../Admin%20page/admin.html";  // Corrected path
                return;
            }

            const storedUserData = localStorage.getItem(emailValue);
            if (storedUserData) {
                const userData = JSON.parse(storedUserData);
                if (userData.password === passwordValue) {
                    if (rememberMe.checked) {
                        localStorage.setItem('rememberedEmail', emailValue);
                        localStorage.setItem('rememberedPassword', passwordValue);
                    } else {
                        localStorage.removeItem('rememberedEmail');
                        localStorage.removeItem('rememberedPassword');
                    }
                    window.location.href = "Voting%20(2)/Voting%20(2).html";
                } else {
                    alert("Invalid login credentials.");
                }
            } else {
                alert("Invalid login credentials.");
            }
        }
    });

    function showError(inputField, message) {
        const errorDiv = document.createElement("div");
        errorDiv.classList.add("error-message");
        errorDiv.innerText = message;
        errorDiv.style.color = "red";
        errorDiv.style.fontSize = "0.9em";
        errorDiv.style.position = "absolute";
        errorDiv.style.marginTop = "2px";
        inputField.parentElement.appendChild(errorDiv);
    }
}

// Load remembered credentials
document.addEventListener('DOMContentLoaded', function () {
    initLoginForm();
    const loginEmailInput = document.querySelector("input[type='email']");
    const loginPasswordInput = document.querySelector("input[type='password']");
    const rememberMeCheckbox = document.querySelector('.remember-forgot input[type="checkbox"]');
    const rememberedEmail = localStorage.getItem('rememberedEmail');
    const rememberedPassword = localStorage.getItem('rememberedPassword');

    if (rememberedEmail && rememberedPassword) {
        loginEmailInput.value = rememberedEmail;
        loginPasswordInput.value = rememberedPassword;
        rememberMeCheckbox.checked = true;
    }
});
