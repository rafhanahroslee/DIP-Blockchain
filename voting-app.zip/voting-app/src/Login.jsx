import React from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const Login = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState("");

  const handleLogin = () => {
    if (role === "admin") {
      navigate("/admin");
    } else if (role === "student") {
      navigate("/vote");
    } else {
      alert("Please select an account type.");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white shadow-md p-8 rounded-lg text-center">
        <h1 className="text-2xl font-bold mb-4">🔐 Login</h1>
        <p className="text-gray-600 mb-4">Select an account type</p>

        <div className="flex flex-col space-y-4">
          <button
            className={`px-6 py-2 rounded-md ${role === "admin" ? "bg-blue-700 text-white" : "bg-gray-300"}`}
            onClick={() => setRole("admin")}
          >
            Admin Login
          </button>

          <button
            className={`px-6 py-2 rounded-md ${role === "student" ? "bg-blue-700 text-white" : "bg-gray-300"}`}
            onClick={() => setRole("student")}
          >
            Student Login
          </button>

          <button
            className="bg-green-500 text-white px-6 py-2 rounded-md hover:bg-green-700"
            onClick={handleLogin}
          >
            Proceed
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
