import { useEffect, useState } from "react";
import { ethers } from "ethers";

const Voting = () => {
  const [account, setAccount] = useState(null);

  const connectWallet = async () => {
    if (!window.ethereum) {
      alert("MetaMask not detected! Please install it first.");
      return;
    }

    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const accounts = await provider.send("eth_requestAccounts", []);
      setAccount(accounts[0]);
    } catch (error) {
      console.error("Wallet connection failed:", error);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white shadow-md p-8 rounded-lg text-center">
        <h1 className="text-2xl font-bold mb-4">🗳️ Voting Page</h1>

        {account ? (
          <p className="text-green-500">✅ Connected: {account.slice(0, 6)}...{account.slice(-4)}</p>
        ) : (
          <button
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
            onClick={connectWallet}
          >
            🔗 Connect Wallet
          </button>
        )}
      </div>
    </div>
  );
};

export default Voting;

