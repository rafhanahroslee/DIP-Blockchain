import { useNavigate } from "react-router-dom";

const AdminDashboard = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white shadow-md p-8 rounded-lg text-center">
        <h1 className="text-2xl font-bold mb-4">🛠️ Admin Dashboard</h1>
        <p className="text-gray-600 mb-4">Manage election settings</p>

        <button
          className="bg-red-500 text-white px-6 py-2 rounded-md hover:bg-red-700"
          onClick={() => navigate("/")}
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default AdminDashboard;

