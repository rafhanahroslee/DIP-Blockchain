import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./Login";  // ✅ Ensure file exists
import AdminDashboard from "./AdminDashboard";  // ✅ Ensure file exists
import Voting from "./Voting";  // ✅ Ensure file exists

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/vote" element={<Voting />} />
      </Routes>
    </Router>
  </React.StrictMode>
);
